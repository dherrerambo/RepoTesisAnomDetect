import os, sys, logging

log_dir = "./logs"
os.makedirs(log_dir, exist_ok=True)

log_filepath = os.path.join(log_dir,"main.log")

logging_str = "[%(asctime)s: %(levelname)s: %(module)s: %(funcName)s: %(message)s]"
logging.basicConfig(
        level= logging.INFO
        , format=logging_str
        , handlers=[
            logging.FileHandler(
                                log_filepath
                                , encoding="utf8"
                            )
            # , logging.StreamHandler(sys.stdout)       ## imprime los losg en consola
        ]
)
logger = logging.getLogger("AnomalyLogger")
